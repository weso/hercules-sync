.. hercules_sync documentation master file, created by
   sphinx-quickstart on Thu Feb 27 08:51:45 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentation of the hercules_sync system
=========================================
In this site you can explore the documentation written for the hercules_sync system.
This system was developed as a component of the Hércules project Ontological Infrastructure.

Main documentation
------------------

.. toctree::
   :maxdepth: 3

   hercules_sync_doc

Code documentation
------------------
Click on the following links to explore the Python docstrings of the system:

* :ref:`genindex`
* :ref:`modindex`
